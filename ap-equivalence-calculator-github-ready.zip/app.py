from pathlib import Path
import tempfile

from flask import Flask, render_template, request, send_file
from werkzeug.utils import secure_filename

from services.validator import validate_file
from services.file_reader import read_file
from services.column_detector import detect_columns
from services.anonymizer import anonymize_dataframe
from services.medication_splitter import split_medications
from services.parser import parse_medication
from services.converter import (
    available_methods,
    available_targets,
    convert_drug,
    normalize_target,
)
from services.exporter import export_results


app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024
METHODS = available_methods()
TARGETS_BY_METHOD = {method: available_targets(method) for method in METHODS}


@app.route("/", methods=["GET", "POST"])
def home():
    result_rows = []
    direct_errors = []
    total_equivalent = None
    selected_method = str(request.form.get("method", "CMD")).strip().upper()
    try:
        selected_target = normalize_target(
            selected_method,
            request.form.get("target_drug"),
        )
    except ValueError:
        selected_target = normalize_target(selected_method)

    medication_text = request.form.get(
        "medication_text",
        "Risperdal 2mg BID, Abilify 15mg QD",
    )

    if request.method == "POST":
        for medication in split_medications(medication_text):
            try:
                parsed = parse_medication(medication)
                equivalent = convert_drug(
                    parsed["drug"],
                    parsed["daily_dose_mg"],
                    method=selected_method,
                    target_drug=selected_target,
                )
                result_rows.append({**parsed, "equivalent_dose_mg": equivalent})
            except (ValueError, LookupError) as exc:
                direct_errors.append({"original": medication, "error": str(exc)})
        total_equivalent = sum(row["equivalent_dose_mg"] for row in result_rows)

    return render_template(
        "index.html",
        methods=METHODS,
        targets_by_method=TARGETS_BY_METHOD,
        selected_method=selected_method,
        selected_target=selected_target,
        medication_text=medication_text,
        result_rows=result_rows,
        direct_errors=direct_errors,
        total_equivalent=total_equivalent,
    )


@app.route("/upload", methods=["POST"])
def upload():
    try:
        file = request.files.get("file")
        validate_file(file)

        method = str(request.form.get("method", "")).strip().upper()
        target_drug = normalize_target(method, request.form.get("target_drug"))

        suffix = Path(secure_filename(file.filename)).suffix.lower()
        with tempfile.NamedTemporaryFile(prefix="ap_upload_", suffix=suffix, delete=False) as tmp:
            upload_path = Path(tmp.name)
        try:
            file.save(upload_path)
            sheets = read_file(upload_path)
        finally:
            upload_path.unlink(missing_ok=True)

        detailed_rows = []
        audit_rows = []
        error_rows = []

        for sheet_name, source_df in sheets.items():
            detected = detect_columns(source_df)
            patient_col = detected["patient_column"]
            medication_col = detected["medication_column"]
            dose_col = detected["dose_column"]
            frequency_col = detected["frequency_column"]

            if medication_col is None:
                error_rows.append({
                    "sheet": sheet_name,
                    "row": None,
                    "patient": None,
                    "original": None,
                    "error": "Medication column not found",
                })
                continue

            anon_df, _ = anonymize_dataframe(source_df)
            for idx, row in anon_df.iterrows():
                patient_id = row[patient_col] if patient_col is not None else f"ROW_{idx + 2:05d}"
                medications = split_medications(row[medication_col])
                if not medications:
                    error_rows.append({
                        "sheet": sheet_name,
                        "row": idx + 2,
                        "patient": patient_id,
                        "original": row[medication_col],
                        "error": "Medication value is empty",
                    })
                    continue

                # Separate dose/frequency columns are only unambiguous for a single
                # medication in the row. Multi-medication rows must carry these in text.
                explicit_dose = row[dose_col] if dose_col is not None and len(medications) == 1 else None
                explicit_frequency = (
                    row[frequency_col]
                    if frequency_col is not None and len(medications) == 1
                    else None
                )

                for medication in medications:
                    try:
                        parsed = parse_medication(
                            medication,
                            explicit_dose=explicit_dose,
                            explicit_frequency=explicit_frequency,
                        )
                        equivalent = convert_drug(
                            parsed["drug"],
                            parsed["daily_dose_mg"],
                            method=method,
                            target_drug=target_drug,
                        )
                    except (ValueError, LookupError) as exc:
                        error_rows.append({
                            "sheet": sheet_name,
                            "row": idx + 2,
                            "patient": patient_id,
                            "original": medication,
                            "error": str(exc),
                        })
                        continue

                    audit_rows.append({
                        "sheet": sheet_name,
                        "patient": patient_id,
                        "original": medication,
                        "parsed": parsed["drug"],
                        "dose_mg": parsed["dose_mg"],
                        "frequency": parsed["frequency"],
                        "frequency_per_day": parsed["frequency_per_day"],
                        "daily_dose_mg": parsed["daily_dose_mg"],
                        "confidence": parsed["confidence"],
                        "parser_method": parsed["parser_method"],
                    })
                    detailed_rows.append({
                        "sheet": sheet_name,
                        "patient": patient_id,
                        "original": medication,
                        "drug": parsed["drug"],
                        "dose_mg": parsed["dose_mg"],
                        "frequency": parsed["frequency"],
                        "frequency_per_day": parsed["frequency_per_day"],
                        "daily_dose_mg": parsed["daily_dose_mg"],
                        "method": method,
                        "target_drug": target_drug,
                        "equivalent_dose_mg": equivalent,
                        "warnings": parsed["warnings"],
                    })

        output_file = export_results(detailed_rows, audit_rows, error_rows)
        return send_file(output_file, as_attachment=True, download_name="result.xlsx")
    except ValueError as exc:
        return {"error": str(exc)}, 400


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
