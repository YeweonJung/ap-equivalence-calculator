PATIENT_KEYWORDS = [
    "id",
    "patient",
    "patient_id",
    "subject",
    "participant",
    "mrn",
    "name"
]

MEDICATION_KEYWORDS = [
    "drug",
    "medication",
    "medications",
    "rx",
    "prescription",
    "medicine"
]

DOSE_KEYWORDS = ["dose", "dose_mg", "strength", "용량"]
FREQUENCY_KEYWORDS = ["frequency", "freq", "schedule", "횟수", "빈도"]


def detect_columns(df):

    patient_col = None
    medication_col = None
    dose_col = None
    frequency_col = None

    for col in df.columns:

        c = (
            str(col)
            .lower()
            .strip()
        )

        if any(
            k in c
            for k in PATIENT_KEYWORDS
        ):
            patient_col = col

        if any(
            k in c
            for k in MEDICATION_KEYWORDS
        ):
            medication_col = col

        if c in DOSE_KEYWORDS:
            dose_col = col

        if c in FREQUENCY_KEYWORDS:
            frequency_col = col

    return {
        "patient_column":
        patient_col,

        "medication_column":
        medication_col,

        "dose_column": dose_col,
        "frequency_column": frequency_col,
    }
