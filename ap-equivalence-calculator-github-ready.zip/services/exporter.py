import tempfile
from pathlib import Path

import pandas as pd


DETAILED_COLUMNS = [
    "sheet", "patient", "original", "drug", "dose_mg", "frequency",
    "frequency_per_day", "daily_dose_mg", "method", "target_drug",
    "equivalent_dose_mg", "patient_total_equivalent_mg", "warnings",
]
AUDIT_COLUMNS = [
    "sheet", "patient", "original", "parsed", "dose_mg", "frequency",
    "frequency_per_day", "daily_dose_mg", "confidence", "parser_method",
]
ERROR_COLUMNS = ["sheet", "row", "patient", "original", "error"]


def export_results(detailed_rows, audit_rows, error_rows):
    output_dir = Path(tempfile.mkdtemp(prefix="ap_equiv_"))
    output_file = output_dir / "result.xlsx"

    detailed_df = pd.DataFrame(detailed_rows, columns=DETAILED_COLUMNS)
    if not detailed_df.empty:
        group_cols = ["sheet", "patient", "method", "target_drug"]
        detailed_df["patient_total_equivalent_mg"] = detailed_df.groupby(
            group_cols, dropna=False
        )["equivalent_dose_mg"].transform("sum").round(6)

    with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
        detailed_df.to_excel(writer, sheet_name="Detailed", index=False)
        pd.DataFrame(audit_rows, columns=AUDIT_COLUMNS).to_excel(
            writer, sheet_name="AuditTrail", index=False
        )
        pd.DataFrame(error_rows, columns=ERROR_COLUMNS).to_excel(
            writer, sheet_name="Errors", index=False
        )

    return output_file
