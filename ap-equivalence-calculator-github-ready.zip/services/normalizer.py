import json

from services.llm_client import ask_llm_json, is_llm_enabled
from services.parser import alias_map, dictionary_match, fuzzy_match


ALLOWED_DRUGS = frozenset(alias_map.values())
MIN_LLM_CONFIDENCE = 0.90


def normalize_drug(text, llm_resolver=ask_llm_json):
    """Normalize with auditable deterministic-first, LLM-last behavior."""
    drug = dictionary_match(text)
    if drug:
        return {"drug": drug, "confidence": 1.0, "parser_method": "dictionary"}

    drug = fuzzy_match(text)
    if drug:
        return {"drug": drug, "confidence": 0.95, "parser_method": "fuzzy"}

    if not is_llm_enabled() and llm_resolver is ask_llm_json:
        raise ValueError("Drug name could not be normalized; LLM correction is not configured")

    prompt = f"""
You normalize an antipsychotic medication name. Return one JSON object only.
Never infer dose or frequency. Select drug only from this allow-list:
{json.dumps(sorted(ALLOWED_DRUGS), ensure_ascii=False)}
Input: {json.dumps(str(text), ensure_ascii=False)}
Schema: {{"drug": "allow-listed generic name or empty string", "confidence": 0.0}}
""".strip()
    try:
        result = llm_resolver(prompt)
        drug = str(result.get("drug", "")).casefold().strip()
        confidence = float(result.get("confidence", 0))
    except Exception as exc:
        raise ValueError("Drug name could not be normalized by the LLM") from exc

    if drug not in ALLOWED_DRUGS or not 0 <= confidence <= 1:
        raise ValueError("LLM returned an unsupported drug name")
    if confidence < MIN_LLM_CONFIDENCE:
        raise ValueError(f"LLM correction requires review (confidence {confidence:.2f})")
    return {"drug": drug, "confidence": confidence, "parser_method": "llm"}
