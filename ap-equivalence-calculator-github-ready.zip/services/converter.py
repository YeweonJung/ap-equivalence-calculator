import math
from pathlib import Path

import pandas as pd


BASE_DIR = Path(__file__).resolve().parents[1]
LOOKUP_FILE = BASE_DIR / "lookup" / "master_lookup.csv"

lookup = pd.read_csv(LOOKUP_FILE)
for column in ("method_id", "source_drug", "target_drug"):
    lookup[column] = lookup[column].astype(str).str.strip().str.casefold()
lookup["method_id"] = lookup["method_id"].str.upper()

DEFAULT_TARGETS = {
    "CMD": "chlorpromazine",
    "CPZ_FGA": "chlorpromazine",
    "DDD": "chlorpromazine",
    "ED95": "olanzapine",
    "MED": "olanzapine",
}


def available_methods():
    return sorted(lookup["method_id"].unique().tolist())


def available_targets(method):
    method = str(method).strip().upper()
    return sorted(lookup.loc[lookup["method_id"] == method, "target_drug"].unique().tolist())


def normalize_target(method, target_drug=None):
    method = str(method).strip().upper()
    if method not in available_methods():
        raise ValueError(f"Unsupported conversion method: {method}")
    target = str(target_drug or DEFAULT_TARGETS.get(method, "olanzapine")).strip().casefold()
    if target not in available_targets(method):
        raise ValueError(f"Target drug '{target}' is not available for method {method}")
    return target


def convert_drug(source_drug, daily_dose, method="CMD", target_drug=None):
    method = str(method).strip().upper()
    source = str(source_drug).strip().casefold()
    target = normalize_target(method, target_drug)

    try:
        dose = float(daily_dose)
    except (TypeError, ValueError) as exc:
        raise ValueError("Daily dose must be numeric") from exc
    if not math.isfinite(dose) or dose <= 0:
        raise ValueError("Daily dose must be a finite number greater than zero")

    result = lookup[
        (lookup["method_id"] == method)
        & (lookup["source_drug"] == source)
        & (lookup["target_drug"] == target)
    ]
    if result.empty:
        raise LookupError(f"No {method} conversion from {source} to {target}")
    if len(result) != 1:
        raise ValueError(f"Duplicate lookup rows for {method}: {source} to {target}")

    factor = float(result.iloc[0]["factor"])
    if not math.isfinite(factor) or factor <= 0:
        raise ValueError("Invalid conversion factor in lookup table")
    # Keep full precision through multi-drug aggregation. Presentation/export
    # layers may round for display after totals have been calculated.
    return dose * factor
