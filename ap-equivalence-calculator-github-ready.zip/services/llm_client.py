import json
import os
import re


def is_llm_enabled():
    return bool(os.getenv("OPENROUTER_API_KEY", "").strip())


def ask_llm_json(prompt):
    """Call OpenRouter without making an API key mandatory at import time."""
    api_key = os.getenv("OPENROUTER_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("LLM normalization is not configured")

    from openai import OpenAI

    client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=api_key)
    response = client.chat.completions.create(
        model=os.getenv("LLM_MODEL", "qwen/qwen3-32b"),
        messages=[{"role": "user", "content": prompt}],
        temperature=0,
    )
    content = response.choices[0].message.content or ""
    content = re.sub(r"^```(?:json)?\s*|\s*```$", "", content.strip(), flags=re.I)
    return json.loads(content)
