import math
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

import pandas as pd

from services.converter import available_targets, convert_drug
from services.exporter import export_results
from services.medication_splitter import split_medications
from services.parser import dictionary_match, parse_medication


class ParserTests(unittest.TestCase):
    def test_brand_dose_and_bid(self):
        parsed = parse_medication("Risperdal 2mg BID")
        self.assertEqual(parsed["drug"], "risperidone")
        self.assertEqual(parsed["dose_mg"], 2)
        self.assertEqual(parsed["frequency_per_day"], 2)
        self.assertEqual(parsed["daily_dose_mg"], 4)

    def test_korean_alias_and_qhs(self):
        parsed = parse_medication("자이프렉사 10 mg qhs")
        self.assertEqual(parsed["drug"], "olanzapine")
        self.assertEqual(parsed["daily_dose_mg"], 10)

    def test_slash_does_not_split_mg_per_day(self):
        self.assertEqual(split_medications("olanzapine 10 mg/day"), ["olanzapine 10 mg/day"])

    def test_short_alias_does_not_match_inside_other_drug(self):
        self.assertNotEqual(dictionary_match("cariprazine 1.5 mg daily"), "aripiprazole")

    def test_nonpositive_dose_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "greater than zero"):
            parse_medication("risperidone 0 mg daily")
        with self.assertRaisesRegex(ValueError, "greater than zero"):
            parse_medication("quetiapine -10 mg daily")

    def test_missing_dose_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "Dose with unit"):
            parse_medication("risperidone BID")

    @patch("services.normalizer.is_llm_enabled", return_value=True)
    def test_llm_corrects_unknown_typo_with_auditable_method(self, _enabled):
        from services.normalizer import normalize_drug

        result = normalize_drug(
            "rissperidonn 2mg BID",
            llm_resolver=lambda _prompt: {"drug": "risperidone", "confidence": 0.97},
        )
        self.assertEqual(result["drug"], "risperidone")
        self.assertEqual(result["parser_method"], "llm")

    @patch("services.normalizer.is_llm_enabled", return_value=True)
    def test_low_confidence_llm_result_is_rejected(self, _enabled):
        from services.normalizer import normalize_drug

        with self.assertRaisesRegex(ValueError, "requires review"):
            normalize_drug(
                "unknown 2mg",
                llm_resolver=lambda _prompt: {"drug": "risperidone", "confidence": 0.60},
            )


class ConversionTests(unittest.TestCase):
    def test_cmd_reference_value(self):
        self.assertEqual(convert_drug("risperidone", 1, "CMD", "olanzapine"), 2.5)

    def test_ddd_reference_value(self):
        self.assertEqual(convert_drug("risperidone", 1, "DDD", "olanzapine"), 2.0)

    def test_med_reference_value(self):
        self.assertAlmostEqual(
            convert_drug("risperidone", 1, "MED", "olanzapine"),
            3.745318,
            places=6,
        )

    def test_reciprocity(self):
        for method in ("CMD", "DDD", "ED95", "MED"):
            targets = available_targets(method)
            for first in targets:
                for second in targets:
                    forward = convert_drug(first, 1, method, second)
                    backward = convert_drug(second, forward, method, first)
                    self.assertTrue(math.isclose(backward, 1, rel_tol=2e-5, abs_tol=2e-5))

    def test_unsupported_pair_is_an_error(self):
        with self.assertRaisesRegex(ValueError, "not available"):
            convert_drug("risperidone", 1, "CPZ_FGA", "olanzapine")

    def test_nonpositive_daily_dose_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "greater than zero"):
            convert_drug("risperidone", -1, "CMD", "olanzapine")


class ExportTests(unittest.TestCase):
    def test_polypharmacy_total_and_error_sheet(self):
        detailed = [
            {
                "sheet": "Sheet1", "patient": "P1", "original": "Risperdal 2mg BID",
                "drug": "risperidone", "dose_mg": 2, "frequency": "BID",
                "frequency_per_day": 2, "daily_dose_mg": 4, "method": "CMD",
                "target_drug": "olanzapine", "equivalent_dose_mg": 10, "warnings": "",
            },
            {
                "sheet": "Sheet1", "patient": "P1", "original": "Abilify 15mg QD",
                "drug": "aripiprazole", "dose_mg": 15, "frequency": "QD",
                "frequency_per_day": 1, "daily_dose_mg": 15, "method": "CMD",
                "target_drug": "olanzapine", "equivalent_dose_mg": 10.714286, "warnings": "",
            },
        ]
        errors = [{"sheet": "Sheet1", "row": 4, "patient": "P2", "original": "unknown 5mg", "error": "Drug name could not be normalized"}]
        output = export_results(detailed, [], errors)
        result = pd.read_excel(output, sheet_name=None)
        self.assertEqual(list(result), ["Detailed", "AuditTrail", "Errors"])
        self.assertAlmostEqual(result["Detailed"].loc[0, "patient_total_equivalent_mg"], 20.714286, places=6)
        self.assertEqual(len(result["Errors"]), 1)


if __name__ == "__main__":
    unittest.main()
