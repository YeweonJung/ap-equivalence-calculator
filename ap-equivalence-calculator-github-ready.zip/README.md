# AP Equivalence Calculator

Research-use antipsychotic dose standardization web app.

Deployed service: https://ap-equivalence-calculator.onrender.com

## Input

Upload CSV, XLS, or XLSX with a medication column (`Medication`, `Drug`, `Rx`,
or similar). A patient/subject column is optional and is anonymized in output.

Medication strings should include a dose with unit and preferably frequency:

```csv
Patient ID,Medication
P001,"Risperdal 2mg BID, Abilify 15mg QD"
P002,Olanzapine 10mg qhs
```

If frequency is absent, the app assumes once daily and records a warning.
Unsupported drugs, invalid doses, and unavailable method/target pairs are
written to `Errors` without aborting the other rows.

## Output

- `Detailed`: parsed dose, daily dose, equivalent dose, and per-patient total.
- `AuditTrail`: normalization and dose/frequency parsing details.
- `Errors`: row-level failures that were excluded from calculation.

## Methods and limitations

The lookup contains CMD, CPZ_FGA, DDD, ED95, and MED estimates. Coverage differs
by method; a missing pair is an explicit error and is never treated as zero.
DDD is a drug-utilization unit and is not an individualized prescribed dose.
This application is for research standardization, not prescribing or switching
decisions.

## Test

```bash
python -m unittest discover -s tests -v
```
